CREATE TABLE `passenger` (
  `id` int NOT NULL AUTO_INCREMENT,
  `survived` int NOT NULL,
  `p_class` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `sex` varchar(10) NOT NULL,
  `age` double DEFAULT NULL,
  `sib_sp` int NOT NULL,
  `parch` int NOT NULL,
  `ticket` varchar(50) NOT NULL,
  `fare` decimal(10,4) NOT NULL,
  `cabin` varchar(20) DEFAULT NULL,
  `embarked` varchar(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
);
--ALTER TABLE `passenger` ADD INDEX `idx_survived` (`survived`);
--ALTER TABLE `passenger` ADD INDEX `idx_p_class` (`p_class`);

