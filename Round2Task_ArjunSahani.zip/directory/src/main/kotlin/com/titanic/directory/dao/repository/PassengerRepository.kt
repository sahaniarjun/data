package com.titanic.directory.dao.repository


import com.titanic.directory.model.Passenger
import org.springframework.data.jpa.repository.JpaRepository

interface PassengerRepository : JpaRepository<Passenger, Long> {
    fun findAllBySurvivedAndPClass(survived: Int, pClass: Int): List<Passenger>
    fun findAllBySurvived(survived: Int): List<Passenger>
    fun findAllByPClass(pClass: Int): List<Passenger>
}

