package com.titanic.directory.model

import jakarta.persistence.Entity
import jakarta.persistence.GeneratedValue
import jakarta.persistence.GenerationType
import jakarta.persistence.Id

@Entity
data class Passenger(
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    val id: Long? = null,
    val survived: Int = 0,
    val pClass: Int = 0,
    val name: String = "",
    val sex: String = "",
    val age: Double? = null,
    val sibSp: Int = 0,
    val parch: Int = 0,
    val ticket: String = "",
    val fare: Double = 0.0,
    val cabin: String? = null,
    val embarked: String? = null
)
