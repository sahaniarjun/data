package com.titanic.directory.service

import com.titanic.directory.dao.PassengerDao
import com.titanic.directory.model.Passenger
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.springframework.stereotype.Service

@Service
class PassengerService(private val passengerDao: PassengerDao) {
    private val logger: Logger = LoggerFactory.getLogger(PassengerService::class.java)

    fun getAllPassengers(survived: Int?, pClass: Int?): List<Passenger> {
        logger.info("Fetching passengers from database by survived: $survived and passengerClass: $pClass")
        // Return the list of passengers based on the survived and pClass parameters
        return passengerDao.findAllPassengers(survived, pClass)
    }
}


