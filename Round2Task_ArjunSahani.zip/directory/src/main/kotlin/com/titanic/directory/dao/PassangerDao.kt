package com.titanic.directory.dao

import com.titanic.directory.dao.repository.PassengerRepository
import com.titanic.directory.model.Passenger
import org.springframework.stereotype.Component


@Component
class PassengerDao(private val passengerRepository: PassengerRepository) {

    fun findAllPassengers(survived: Int?, pClass: Int?): List<Passenger> {
        return when {
            survived != null && pClass != null -> passengerRepository.findAllBySurvivedAndPClass(survived, pClass)
            survived != null -> passengerRepository.findAllBySurvived(survived)
            pClass != null -> passengerRepository.findAllByPClass(pClass)
            else -> passengerRepository.findAll()
        }
    }
}