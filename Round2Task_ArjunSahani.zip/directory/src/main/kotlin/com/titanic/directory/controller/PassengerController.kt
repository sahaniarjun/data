package com.titanic.directory.controller

import com.titanic.directory.model.Passenger
import com.titanic.directory.service.PassengerService
import org.springframework.cache.annotation.Cacheable
import org.springframework.data.repository.query.Param
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RestController

@RestController
@RequestMapping("/passengers")
class PassengerController(private val passengerService: PassengerService) {

    @GetMapping
    @Cacheable("passengers")
    fun getAllPassengers(
        @Param("survived") survived: Int?,
        @Param("pClass") pClass: Int?
    ): List<Passenger> {
        // Validate the survived and pClass parameters
        require(!(survived != null && survived !in 0..1)) { "Survived must be either 0 or 1" }
        require(!(pClass != null && pClass !in 1..3)) { "Passenger class must be between 1 and 3" }
        // Return the list of passengers based on the survived and pClass parameters
        return passengerService.getAllPassengers(survived, pClass);
    }


}


